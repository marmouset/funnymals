<?php
// src\Perso\GalerieBundle\AugmenteVues\AugmenteVuesEvents.php

namespace Perso\GalerieBundle\AugmenteVues;

final class AugmenteVuesEvents
{
    const onViewPhoto = 'persogalerie.augmentevues.view_photo';

}