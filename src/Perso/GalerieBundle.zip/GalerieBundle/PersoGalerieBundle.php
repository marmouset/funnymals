<?php

namespace Perso\GalerieBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PersoGalerieBundle extends Bundle
{
}
